plugins { id("com.android.application"); id("org.jetbrains.kotlin.android"); id("org.jetbrains.kotlin.kapt") }
android {
  namespace = "com.jihad.chatviewer"
  compileSdk = 35
  defaultConfig { applicationId = "com.jihad.chatviewer"; minSdk = 26; targetSdk = 35; versionCode = 1; versionName = "1.0" }
  buildFeatures { compose = true }
  composeOptions { kotlinCompilerExtensionVersion = "1.5.0" }
}
dependencies {
  implementation("androidx.core:core-ktx:1.10.1")
  implementation("androidx.activity:activity-compose:1.8.0")
  implementation("androidx.compose.ui:ui:1.5.0")
  implementation("androidx.compose.material3:material3:1.1.0")
  implementation("androidx.compose.material:material-icons-extended:1.5.0")
  implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.6.1")
  implementation("androidx.navigation:navigation-compose:2.6.0")
  implementation("androidx.room:room-runtime:2.5.2")
  implementation("androidx.work:work-runtime-ktx:2.8.1")
  implementation("androidx.datastore:datastore-preferences:1.0.0")
  implementation("io.coil-kt:coil-compose:2.4.0")
  implementation("com.google.code.gson:gson:2.10.1")
  implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.7.3")
  implementation("androidx.documentfile:documentfile:1.0.1")
}
